package com.example.social.controller;

import com.example.social.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.social.service.UserService;

@RestController
@CrossOrigin
public class UserController {
    @Autowired
    UserService us;
    @PostMapping("/register")
    public User register(@RequestBody User u){
        return us.register(u);
    }
    @PostMapping("/login")
    public User login(String username,String password){
        return us.login(username, password);
    }
    @PostMapping("/updateuserdetails")
    public User update(User u){
        return us.updateUser(u);
    }
}
